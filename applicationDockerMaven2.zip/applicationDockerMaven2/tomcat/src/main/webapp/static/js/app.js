'use strict';
// declaration de module
var App = angular.module('myApp',[]);


